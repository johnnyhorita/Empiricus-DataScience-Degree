# Databricks notebook source
# MAGIC 
# MAGIC %md
# MAGIC **Definindo Parametros**

# COMMAND ----------

# TODO
username = 'jhorita'
project = 'northwind'
print (f"username: {username}")
print (f"project: {project}")

# COMMAND ----------

# MAGIC 
# MAGIC %md
# MAGIC **Definindo Caminho dos Dados**

# COMMAND ----------

northwind_data = f"/LetsCode/Big Data/Projeto/{project}/{username}/"
print ("Variável: northwind_data")
print (f"Caminho definido: {northwind_data}\n")

northwind_data_raw = f"/LetsCode/Big Data/Projeto/{project}/{username}/raw/"
print ("Variável: northwind_data_raw")
print (f"Caminho definido: {northwind_data_raw}\n")

northwind_data_trusted = f"/LetsCode/Big Data/Projeto/{project}/{username}/trusted/"
print ("Variável: northwind_data_trusted")
print (f"Caminho definido: {northwind_data_trusted}\n")

northwind_data_refined = f"/LetsCode/Big Data/Projeto/{project}/{username}/refined/"
print ("Variável: northwind_data_refined")
print (f"Caminho definido: {northwind_data_refined}\n")

# COMMAND ----------

# MAGIC %md
# MAGIC **Configurando Banco de Dados**

# COMMAND ----------

spark.sql(f"CREATE DATABASE IF NOT EXISTS {project}_{username}")
spark.sql(f"USE {project}_{username}")

print (f"Database: {project}_{username}")

# COMMAND ----------

# MAGIC %md
# MAGIC **Configurando Banco de Dados Datawarehouse**

# COMMAND ----------

#spark.sql(f"DROP DATABASE IF EXISTS {project}_{username}_dw CASCADE")
spark.sql(f"CREATE DATABASE IF NOT EXISTS {project}_{username}_dw")

print (f"Database: {project}_{username}_dw")

# COMMAND ----------

# MAGIC %md
# MAGIC **Importando Funções**

# COMMAND ----------

# MAGIC %run ./utilities

# COMMAND ----------

print (f"utilities importado...")

# COMMAND ----------

