# Databricks notebook source
# Importando bibliotecas
from pyspark.sql.session import SparkSession
from urllib.request import urlretrieve
from pyspark.sql.functions import col, avg, max, stddev, sum, count
from delta.tables import DeltaTable

import time


# COMMAND ----------

# Variáveis

# Variavel com o endereço dos arquivos de dados CSV's do banco de dados Northwind
BASE_URL = "https://raw.githubusercontent.com/johnnyhorita/empiricus-datascience-degree/main/780/Modulo-07-Big-Data/Projeto/Northwind/data/csv/"


# COMMAND ----------

# Função para carregar dados

def retrieve_data(file: str,  path: str) -> bool:
  """
  Função para efetuar download de arquivo
  
  Parametros
  file: Definir o nome do arquivo com extensão 
  path: Definir o caminho físico de destino do arquivo
  
  Exemplo
  retrieve_data("categories.csv", northwind_data + "raw/")
  """
  file, dbfsPath, driverPath = _generate_file_handles(file, path)
  uri = BASE_URL + file
  urlretrieve(uri, file)
  dbutils.fs.mv(driverPath, dbfsPath)
  return True
  
def _generate_file_handles(file: str, path: str):
  file = f"{file}"
  dbfsPath = path
  dbfsPath += file
  driverPath = "file:/databricks/driver/" + file
  return file, dbfsPath, driverPath

# COMMAND ----------

# Função para carregar os dados em dataframe

def file_data_csv(file: str,  path: str):
  """
  Função para carregar o arquivo em dataframe
  
  Parametros
  file: Definir o nome do arquivo com extensão 
  path: Definir o caminho físico de destino do arquivo
  
  Exemplo
  df = file_data_csv("customers.csv", northwind_data + "raw/")
  """

  # Arquivo localização e tipo
  file = f"{file}"
  dbfsPath = "dbfs:" + path
  dbfsPath += file

  file_type = "csv"

  # CSV opções
  infer_schema = "false"
  first_row_is_header = "true"
  delimiter = ","

  try:
    df = spark.read.format(file_type) \
      .option("inferSchema", infer_schema) \
      .option("header", first_row_is_header) \
      .option("sep", delimiter) \
      .load(dbfsPath)

  except:
    print(f"Erro! Ocorreu algum problema na criação do dataframe para o arquivo {file}.")
  
  else:
    file_df = file.replace(".csv", "")
    print(f"Dataframe df['{file_df}'] criado com sucesso para o arquivo {file}.")
    return df


# COMMAND ----------

# Exemplo
#northwind_data = f"/LetsCode/Big Data/Projeto/northwind/jhorita/"
#df = file_data_csv("customers.csv", northwind_data + "raw/")
#display(df)

# COMMAND ----------

# função para converter o tipo de dados das colunas definidas na lista

def cast_columns(dataframe: str, columns_to_cast: list, dtype: str):
  """
  Função para converter o tipo de dados das colunas definidas na lista
  
  Parametros
  dataframe: Definir o nome do dataframe;
  columns_to_cast: Definir a lista com as colunas que serão convertidas;
  dtype: Definir o tipo de dado da coluna
  
  Exemplo
  df = cast_columns(df['categories'], columns_to_cast, 'integer')
  """  
  df_cast = (
     dataframe
     .select(
       *(c for c in dataframe.columns if c not in columns_to_cast),
       *(col(c).cast(dtype).alias(c) for c in columns_to_cast)
     )
  )
  return (df_cast)


# COMMAND ----------

# Exemplo
#columns_to_cast = ['categoryID']
#categoriesCast = cast_columns(df['categories'], columns_to_cast, 'integer')


# COMMAND ----------

# função para salvar o dataframe na camada trusted

def save_trusted(dataframe, path: str, is_partition: bool, partitionCol: str):
  """
  Função para salvar o dataframe na camada trusted em formato parquet
  
  Parametros
  dataframe: Definir o nome do dataframe;
  path: Definir o caminho físico de destino do arquivo;
  is_partition: Definir se o arquivo será particionado;
  partitionCol: Definir o nome da coluna da partição;
  
  Exemplo
  save_trusted(categoriesCast, northwind_data_trusted, "False", "") 
  """
  try:
    if is_partition == True:
      (dataframe.write
       .mode("overwrite")
       .format("parquet")
       .partitionBy(partitionCol)
       .save(path))
    else:
      (dataframe.write
       .mode("overwrite")
       .format("parquet")
       .save(path))
  
    print(f"Dataframe gravado com sucesso em {path}.")
  
  except:
    print(f"Erro! Ocorreu algum problema na gravação do dataframe.") 
   
  return


# COMMAND ----------

# Função para identificar se os elementos de uma lista estão contidos em outra lista

confirm_column_cast = lambda searchList, elem: [[i for i, x in enumerate(searchList) if x == e] for e in elem]

# COMMAND ----------

# Função para criar tabela utilizando  biblioteca spark

def spark_create_table(tablename: str, path: str, is_partition: bool, partitionCol: str):
  """
  Função para criar uma tabela utilizando a biblioteca spark com comando SQL
  
  Parametros
  tablename: Definir o nome da tabela;
  path: Definir o caminho físico de destino do arquivo;
  is_partition: Definir se o arquivo será particionado;
  partitionCol: Definir o nome da coluna da partição;
  
  Exemplo
  spark_create_table(tablename, northwind_data_trusted, "False", "")
  """
  try:
    path = path + tablename

    spark.sql(
        f"""
    DROP TABLE IF EXISTS {tablename}
    """
    )

    if is_partition == True:
      spark.sql(
        f"""
        CREATE TABLE {tablename}
        USING PARQUET
        #PARTITIONED BY ({partitionCol})
        LOCATION "{path}"
        """
        )    
    else:
      spark.sql(
        f"""
        CREATE TABLE {tablename}
        USING PARQUET
        LOCATION "{path}"
        """
        )

    spark.catalog.refreshTable(tablename)
    
    print(f"Tabela {tablename} criada com sucesso.")
    
  except:
    print(f"Erro! Ocorreu algum problema na criação da tabela.")
  
  return


# COMMAND ----------

#Exemplo
#spark_create_table("customers", "/LetsCode/Big Data/Projeto/northwind/jhorita/trusted/", "True", "country")

# COMMAND ----------

# Função para criar tabela utilizando biblioteca spark

def spark_create_table_dw(tablename: str, path: str, sqlcmd: str, database: str):
  """
  Função para criar um dataframe baseado em pesquisa SQL (Query script),
  salvar o dataframe em formato DELTA e,
  registrar a tabela no Metastore
   
  Parametros
  tablename: Definir o nome da tabela;
  path: Definir o caminho físico de destino do arquivo;
  sqlcmd: Definir o script de pesquisa para o conjunto de dados para criação do dataframe;
  database: Definir o nome do banco de dados para persistência da tabela;
  
  Exemplo
  spark_create_table_dw("dm_customers", northwind_data_refined, sqlcmd, "northwind_jhorita_DW")
  """
  try:
    path = northwind_data_refined + tablename
    print(f"Definição do local de armazenamento: {path}")   

    df = spark.sql(sqlcmd)
    print(f"Dataframe gerado com sucesso.")

    # Apagar o arquivo relacionado
    dbutils.fs.rm(path, recurse=True)    
    
    # Gravar o dataframe no formato Delta
    (df.write
     .format("delta")
     .mode("overwrite")
     .save(path))
    print(f"Dataframe salvo com sucesso.")

    # Registrar a tabela Delta no Metastore
    spark.sql(f"""
    DROP TABLE IF EXISTS {database}.{tablename}
    """)

    spark.sql(f"""
    CREATE TABLE {database}.{tablename}
    USING DELTA
    LOCATION "{path}"
    """)
    print(f"Tabela {tablename} criada com sucesso.")

    describe = spark.sql(f"""
    DESCRIBE EXTENDED {database}.{tablename}
    """)

    display(describe)
    
  except:
    print(f"Erro! Ocorreu algum problema na criação da tabela.")
  
  return


# COMMAND ----------

# Exemplo
#spark.sql(f"USE northwind_jhorita")

#sqlcmd = f"""
#  SELECT row_number() OVER (ORDER BY customerID) customerID_sk, customerID, companyName, contactName, contactTitle, address, city, region, #postalCode, country, phone, fax
# FROM customers;
#  """
#northwind_data_refined = "/LetsCode/Big Data/Projeto/northwind/jhorita/refined/"
#spark_create_table_dw("dm_customers", northwind_data_refined, sqlcmd, "northwind_jhorita_DW")

# COMMAND ----------

