# Databricks notebook source
# MAGIC %md
# MAGIC # Projeto Big Data Northwind 
# MAGIC 
# MAGIC Criar ambiente Big Data para analisar dados da empresa Northwind<br><br>
# MAGIC 1. Exportar as tabelas do Northwind em .CSV.<br>
# MAGIC 2. Carregar para camada Raw de um Data Lake no DBFS.
# MAGIC 3. Salvar dados em formato parquet em uma segunda camada, trusted.
# MAGIC 4. Criar, na camada refined, um datawarehouse utilizando Delta Tables com ao menos duas tabelas agregadas.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Configuração obrigatória
# MAGIC 
# MAGIC Antes de executar a célula abaixo altere os parametros do username e project do arquivo:
# MAGIC <a href="$./includes/configuration" target="_blank">
# MAGIC includes/configuration</a>

# COMMAND ----------

# MAGIC %run ./includes/configuration

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ## Limpeza do diretório Principal

# COMMAND ----------

# Limpeza do diretório principal
print(f"Caminho: {northwind_data}")
try:
  dbutils.fs.rm(northwind_data, recurse=True)
  print(f"Limpeza concluida com sucesso.")
except:
  print(f"Erro! Ocorreu algum problema na limpeza.")


# COMMAND ----------

# MAGIC %md
# MAGIC # Camada raw
# MAGIC 
# MAGIC **Objetivo:** 
# MAGIC 
# MAGIC Neste trecho vamos carregar os arquivos CSVs exportados do banco de dados Northwind para a primera camada do Data Lake, o diretório `raw`.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Limpeza do diretório

# COMMAND ----------

# Limpeza do diretório raw
print(f"Caminho: {northwind_data_raw}")
try:
  #dbutils.fs.rm(northwind_data, recurse=True)
  dbutils.fs.rm(northwind_data_raw, recurse=True)
  print("Limpeza concluida com sucesso.")
except:
  print("Erro! Ocorreu algum problema na limpeza.")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Obter arquivos

# COMMAND ----------

# MAGIC %md
# MAGIC #### Lista de arquivos

# COMMAND ----------

lista_northwind = ["categories.csv", 
                  "customers.csv", 
                  "employee_territories.csv", 
                  "employees.csv", 
                  "order_details.csv", 
                  "orders.csv", 
                  "products.csv", 
                  "regions.csv", 
                  "shippers.csv", 
                  "suppliers.csv", 
                  "territories.csv"]

numero_elementos = len(lista_northwind)

print(f"Quantidade de arquivos: {numero_elementos}")


# COMMAND ----------

# MAGIC %md
# MAGIC #### Importar arquivos
# MAGIC 
# MAGIC Neste trecho estamos importando todos os arquicos CSV's com dados referente as tabelas do banco de dados Nothwind, os arquivos estão disponíveis em 
# MAGIC 
# MAGIC Vamos utilizar a função `retrieve_data` para obter os dados dos arquivos CSVs referentes as tabelas do banco de dados Northwind.
# MAGIC 
# MAGIC A função recebe os argumentos:
# MAGIC - file (str): Definir o nome do arquivo com extensão 
# MAGIC - path (str): Definir o caminho físico de destino do arquivo

# COMMAND ----------

ct = 0
for arquivo in lista_northwind:
  print(f"Carregando arquivo [{arquivo}]...")
  try:
    retrieve_data(arquivo, northwind_data_raw)
    print(f"Carregado com sucesso.")
    ct += 1
  except:
    print(f"Erro ao carregar o arquivo.")

print(f"\nQuantidade de arquivos: {ct}")    
print(f"Processo de importação finalizado.")


# COMMAND ----------

# MAGIC %md
# MAGIC #### Verificar arquivos

# COMMAND ----------

# Validando se todos os arquivos foram carregados para o repositório raw
ct = 0 
for arquivo in lista_northwind:
  try:
    assert arquivo in [item.name for item in dbutils.fs.ls(northwind_data_raw)]
  except:
    print(f"Arquivo {arquivo} não encontrado no repositório raw")
  else:
    print(f"Arquivo {arquivo} encontrado.")
    ct += 1

print(f"\nQuantidade de arquivos: {ct}")
print(f"Processo de verificação finalizado.")


# COMMAND ----------

# MAGIC %md
# MAGIC #### Mostrar os arquivos

# COMMAND ----------

display(dbutils.fs.ls(northwind_data_raw))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Revisar e Visualizar Dados
# MAGIC 
# MAGIC Vamos utilizar a função `file_data_csv` para carregar os arquivos importados em dataframes.
# MAGIC 
# MAGIC A função recebe os argumentos:
# MAGIC - file (str): Definir o nome do arquivo com extensão 
# MAGIC - path (str): Definir o caminho físico de destino do arquivo11

# COMMAND ----------

# MAGIC %md
# MAGIC #### Criar dataframes
# MAGIC 
# MAGIC Vamos utilizar a função `file_data_csv` para carregar/transferir o arquivo para dataframe.
# MAGIC 
# MAGIC A função recebe os argumentos:
# MAGIC 
# MAGIC file: str
# MAGIC path: str

# COMMAND ----------

# Criando dataframes

df = dict()

ct = 0
for arquivo in lista_northwind:
  try:
    df_arquivo = arquivo.replace(".csv", "")
    df[df_arquivo] = file_data_csv(arquivo, northwind_data_raw)
    ct += 1
  except:
    print(f"Erro ao criar o dataframe.")

print(f"\nQuantidade de arquivos: {ct}")
print(f"Processo finalizado.")


# COMMAND ----------

# MAGIC %md
# MAGIC #### Visualizar Dataframes

# COMMAND ----------

# MAGIC %md
# MAGIC #####  Informações dos Dataframes

# COMMAND ----------

for arquivo in lista_northwind:
  df_arquivo = arquivo.replace(".csv", "")
  print(f"\nDataframe df['{df_arquivo}']")
  try:
    a = df[df_arquivo].dtypes
    print(a)
  except:
    print(f"Erro ao criar o dataframe.")
print(f"Processo finalizado.")


# COMMAND ----------

# MAGIC %md
# MAGIC ##### Conteudo dos Dataframes (display)

# COMMAND ----------

# Variaveis 
# Quantidade de registros apresentados nos dataframes, será utilizado para dataframes maiores orders e order_details
qtd_lin = 5


# COMMAND ----------

# MAGIC %md
# MAGIC ###### categories

# COMMAND ----------

display(df['categories'])

# COMMAND ----------

# MAGIC %md
# MAGIC ###### customers

# COMMAND ----------

display(df['customers'].head(qtd_lin))

# COMMAND ----------

# MAGIC %md
# MAGIC ###### employee_territories

# COMMAND ----------

display(df['employee_territories'])

# COMMAND ----------

# MAGIC %md
# MAGIC ###### employees 

# COMMAND ----------

display(df['employees'])

# COMMAND ----------

# MAGIC %md
# MAGIC ###### order_details

# COMMAND ----------

display(df['order_details'].head(qtd_lin))

# COMMAND ----------

# MAGIC %md
# MAGIC ###### orders

# COMMAND ----------

display(df['orders'].head(qtd_lin))

# COMMAND ----------

# MAGIC %md
# MAGIC ###### products

# COMMAND ----------

display(df['products'])

# COMMAND ----------

# MAGIC %md
# MAGIC ###### regions

# COMMAND ----------

display(df['regions'])

# COMMAND ----------

# MAGIC %md
# MAGIC ###### shippers

# COMMAND ----------

display(df['shippers'])

# COMMAND ----------

# MAGIC %md
# MAGIC ###### suppliers

# COMMAND ----------

display(df['suppliers'])

# COMMAND ----------

# MAGIC %md
# MAGIC ###### territories

# COMMAND ----------

display(df['territories'])

# COMMAND ----------



# COMMAND ----------

# MAGIC %md
# MAGIC # Camada trusted
# MAGIC 
# MAGIC **Objetivo:** 
# MAGIC 
# MAGIC Neste trecho vamos tratar os dataframes originados dos arquivos exportados para a segunda camada do Data Lake, o diretório `trusted`.

# COMMAND ----------

# MAGIC %md
# MAGIC ### Limpeza do diretório

# COMMAND ----------

# Limpeza do diretório Trusted
print(f"Caminho: {northwind_data_trusted}")
try:
  dbutils.fs.rm(northwind_data_trusted, recurse=True)
  print("Limpeza concluida com sucesso.")
except:
  print("Erro! Ocorreu algum problema na limpeza.")


# COMMAND ----------

# MAGIC %md
# MAGIC ### Transformar os dados
# MAGIC 
# MAGIC Todos os atributos dos arquivos foram importados como caracteres, dessa forma todas as colunas dos dataframes criados estão definidos como string.
# MAGIC 
# MAGIC Para melhor definição vamos transformar os tipos dos dados conforme sua atribuição.
# MAGIC 
# MAGIC Listaremos em cada dataframe apenas as colunas que serão transformadas/convertidas e as demais colunas serão mantidas como string.
# MAGIC 
# MAGIC Vamos utilizar a função `cast_columns` para converter uma lista de colunas para o um tipo de dado.
# MAGIC 
# MAGIC A função recebe os argumentos:
# MAGIC - dataframe (dataframe): Definir o nome do dataframe;
# MAGIC - columns_to_cast (list): Definir a lista com as colunas que serão convertidas;
# MAGIC - dtype (str): Definir o tipo de dado da coluna

# COMMAND ----------

# MAGIC %md
# MAGIC #### categories
# MAGIC 
# MAGIC Conversões:
# MAGIC - `categoryID` de `string` para `integer`

# COMMAND ----------

# Converte o(s) datatype da(s) coluna(s) informada(s)
try:
  columns_to_cast = ['categoryID']
  categoriesCast = cast_columns(df['categories'], columns_to_cast, 'integer')
  print("Conversão de dados concluida com sucesso.")
except:
  print("Erro! Ocorreu algum problema na conversão de dados.")
  

# COMMAND ----------

# Verifica se a(s) coluna(s) foi/foram convertida(s) apresentando o index da(s) coluna(s)
columns_type = [('categoryID', 'int')]
df_type = categoriesCast.dtypes
confirm_column_cast(df_type,columns_type)


# COMMAND ----------

# Apresenta o novo dataframe criado com as colunas convertidas
categoriesCast


# COMMAND ----------

# MAGIC %md
# MAGIC #### customers
# MAGIC 
# MAGIC Conversões:
# MAGIC - `Sem conversões`

# COMMAND ----------

# Apresenta o novo dataframe criado com as colunas convertidas
customersCast = df['customers']
customersCast


# COMMAND ----------

# MAGIC %md
# MAGIC #### employee_territories
# MAGIC 
# MAGIC Conversões:
# MAGIC - `employeeID` de `string` para `integer`

# COMMAND ----------

# Converte o(s) datatype da(s) coluna(s) informada(s)
try:
  columns_to_cast = ['employeeID']
  employee_territoriesCast = cast_columns(df['employee_territories'], columns_to_cast, 'integer')
  print("Conversão de dados concluida com sucesso.")
except:
  print("Erro! Ocorreu algum problema na conversão de dados.")
  

# COMMAND ----------

# Verifica se a(s) coluna(s) foi/foram convertida(s) apresentando o index da(s) coluna(s)
columns_type = [('employeeID', 'int')]
df_type = employee_territoriesCast.dtypes
confirm_column_cast(df_type,columns_type)


# COMMAND ----------

# Apresenta o novo dataframe criado com as colunas convertidas
employee_territoriesCast


# COMMAND ----------

# MAGIC %md
# MAGIC #### employees
# MAGIC 
# MAGIC Conversões:
# MAGIC - `employeeID` de `string` para `integer`
# MAGIC - `reportsTo` de `string` para `integer`
# MAGIC - `birthDate` de `string` para `date`
# MAGIC - `hireDate` de `string` para `date`

# COMMAND ----------

# Converte o(s) datatype da(s) coluna(s) informada(s)
try:
  columns_to_cast = ['employeeID','reportsTo']
  employeesCast = cast_columns(df['employees'], columns_to_cast, 'integer')
  
  columns_to_cast = ['birthDate', 'hireDate']
  employeesCast = cast_columns(employeesCast, columns_to_cast, 'date')
  
  print("Conversão de dados concluida com sucesso.")
except:
  print("Erro! Ocorreu algum problema na conversão de dados.")
  

# COMMAND ----------

# Verifica se a(s) coluna(s) foi/foram convertida(s) apresentando o index da(s) coluna(s)
columns_type = [('employeeID', 'int'), ('reportsTo', 'int'), ('birthDate', 'date'), ('hireDate', 'date')]
df_type = employeesCast.dtypes
confirm_column_cast(df_type,columns_type)


# COMMAND ----------

# Apresenta o novo dataframe criado com as colunas convertidas
employeesCast


# COMMAND ----------

# MAGIC %md
# MAGIC #### order_details
# MAGIC 
# MAGIC Conversões:
# MAGIC - `orderID` de `string` para `integer`
# MAGIC - `productID` de `string` para `integer`
# MAGIC - `quantity` de `string` para `integer`
# MAGIC - `unitPrice` de `string` para `float`
# MAGIC - `discount` de `string` para `float`

# COMMAND ----------

# Converte o(s) datatype da(s) coluna(s) informada(s)
try:
  columns_to_cast = ['orderID','productID','quantity']
  order_detailsCast = cast_columns(df['order_details'], columns_to_cast, 'integer')
  
  columns_to_cast = ['unitPrice','discount']
  order_detailsCast = cast_columns(order_detailsCast, columns_to_cast, 'float')
  
  print("Conversão de dados concluida com sucesso.")
except:
  print("Erro! Ocorreu algum problema na conversão de dados.")
  

# COMMAND ----------

# Verifica se a(s) coluna(s) foi/foram convertida(s) apresentando o index da(s) coluna(s)
columns_type = [('orderID', 'int'), ('productID', 'int'), ('quantity', 'int'), ('unitPrice', 'float'), ('discount', 'float')]
df_type = order_detailsCast.dtypes
confirm_column_cast(df_type,columns_type)


# COMMAND ----------

# Apresenta o novo dataframe criado com as colunas convertidas
order_detailsCast


# COMMAND ----------

# MAGIC %md
# MAGIC #### orders
# MAGIC 
# MAGIC Conversões:
# MAGIC - `orderID` de `string` para `integer`
# MAGIC - `employeeID` de `string` para `integer`
# MAGIC - `shipVia` de `string` para `integer`
# MAGIC - `orderDate` de `string` para `date`
# MAGIC - `requiredDate` de `string` para `date`
# MAGIC - `shippedDate` de `string` para `date`
# MAGIC - `freight` de `string` para `float`

# COMMAND ----------

# Converte o(s) datatype da(s) coluna(s) informada(s)
try:
  columns_to_cast = ['orderID','employeeID','shipVia']
  ordersCast = cast_columns(df['orders'], columns_to_cast, 'integer')
  
  columns_to_cast = ['orderDate','requiredDate','shippedDate']
  ordersCast = cast_columns(ordersCast, columns_to_cast, 'date')

  columns_to_cast = ['freight']
  ordersCast = cast_columns(ordersCast, columns_to_cast, 'float')
  
  print("Conversão de dados concluida com sucesso.")
except:
  print("Erro! Ocorreu algum problema na conversão de dados.")
  

# COMMAND ----------

# Verifica se a(s) coluna(s) foi/foram convertida(s) apresentando o index da(s) coluna(s)
columns_type = [('orderID','int'),('employeeID','int'),('shipVia','int'),('orderDate','date'),('requiredDate','date'),('shippedDate','date'),('freight','float')]
df_type = ordersCast.dtypes
confirm_column_cast(df_type,columns_type)


# COMMAND ----------

# Apresenta o novo dataframe criado com as colunas convertidas
ordersCast


# COMMAND ----------

# MAGIC %md
# MAGIC #### products
# MAGIC 
# MAGIC Conversões:
# MAGIC - `productID` de `string` para `integer`
# MAGIC - `supplierID` de `string` para `integer`
# MAGIC - `categoryID` de `string` para `integer`
# MAGIC - `unitsInStock` de `string` para `integer`
# MAGIC - `unitsOnOrder` de `string` para `integer`
# MAGIC - `reorderLevel` de `string` para `integer`
# MAGIC - `unitPrice` de `string` para `float`
# MAGIC - `discontinued` de `string` para `binary`

# COMMAND ----------

# Converte o(s) datatype da(s) coluna(s) informada(s)
try:
  columns_to_cast = ['productID','supplierID','categoryID','unitsInStock','unitsOnOrder','reorderLevel']
  productsCast = cast_columns(df['products'], columns_to_cast, 'integer')
  
  columns_to_cast = ['unitPrice']
  productsCast = cast_columns(productsCast, columns_to_cast, 'float')
  
  columns_to_cast = ['discontinued']
  productsCast = cast_columns(productsCast, columns_to_cast, 'binary')
  
  print("Conversão de dados concluida com sucesso.")
except:
  print("Erro! Ocorreu algum problema na conversão de dados.")
  

# COMMAND ----------

# Verifica se a(s) coluna(s) foi/foram convertida(s) apresentando o index da(s) coluna(s)
columns_type = [('productID','int'),('supplierID','int'),('categoryID','int'),('unitsInStock','int'),('unitsOnOrder','int'),('reorderLevel','int'), ('unitPrice','float'),('discontinued','binary')]
df_type = productsCast.dtypes
confirm_column_cast(df_type,columns_type)


# COMMAND ----------

# Apresenta o novo dataframe criado com as colunas convertidas
productsCast


# COMMAND ----------

# MAGIC %md
# MAGIC #### regions
# MAGIC 
# MAGIC Conversões:
# MAGIC - `regionID` de `string` para `integer`

# COMMAND ----------

# Converte o(s) datatype da(s) coluna(s) informada(s)
try:
  columns_to_cast = ['regionID']
  regionsCast = cast_columns(df['regions'], columns_to_cast, 'integer')
  
  print("Conversão de dados concluida com sucesso.")
except:
  print("Erro! Ocorreu algum problema na conversão de dados.")
  

# COMMAND ----------

# Verifica se a(s) coluna(s) foi/foram convertida(s) apresentando o index da(s) coluna(s)
columns_type = [('regionID','int')]
df_type = regionsCast.dtypes
confirm_column_cast(df_type,columns_type)


# COMMAND ----------

# Apresenta o novo dataframe criado com as colunas convertidas
regionsCast


# COMMAND ----------

# MAGIC %md
# MAGIC #### shippers
# MAGIC 
# MAGIC Conversões:
# MAGIC - `shipperID` de `string` para `integer`

# COMMAND ----------

# Converte o(s) datatype da(s) coluna(s) informada(s)
try:
  columns_to_cast = ['shipperID']
  shippersCast = cast_columns(df['shippers'], columns_to_cast, 'integer')
  
  print("Conversão de dados concluida com sucesso.")
except:
  print("Erro! Ocorreu algum problema na conversão de dados.")


# COMMAND ----------

# Verifica se a(s) coluna(s) foi/foram convertida(s) apresentando o index da(s) coluna(s)
columns_type = [('shipperID','int')]
df_type = shippersCast.dtypes
confirm_column_cast(df_type,columns_type)


# COMMAND ----------

# Apresenta o novo dataframe criado com as colunas convertidas
shippersCast


# COMMAND ----------

# MAGIC %md
# MAGIC #### suppliers
# MAGIC 
# MAGIC Conversões:
# MAGIC - `supplierID` de `string` para `integer`

# COMMAND ----------

# Converte o(s) datatype da(s) coluna(s) informada(s)
try:
  columns_to_cast = ['supplierID']
  suppliersCast = cast_columns(df['suppliers'], columns_to_cast, 'integer')
  
  print("Conversão de dados concluida com sucesso.")
except:
  print("Erro! Ocorreu algum problema na conversão de dados.")
  

# COMMAND ----------

# Verifica se a(s) coluna(s) foi/foram convertida(s) apresentando o index da(s) coluna(s)
columns_type = [('supplierID','int')]
df_type = suppliersCast.dtypes
confirm_column_cast(df_type,columns_type)


# COMMAND ----------

# Apresenta o novo dataframe criado com as colunas convertidas
suppliersCast


# COMMAND ----------

# MAGIC %md
# MAGIC #### territories
# MAGIC 
# MAGIC Conversões:
# MAGIC - `territoryID` de `string` para `integer`
# MAGIC - `regionID` de `string` para `integer`

# COMMAND ----------

# Converte o(s) datatype da(s) coluna(s) informada(s)
try:
  columns_to_cast = ['territoryID','regionID']
  territoriesCast = cast_columns(df['territories'], columns_to_cast, 'integer')
  
  print("Conversão de dados concluida com sucesso.")
except:
  print("Erro! Ocorreu algum problema na conversão de dados.")
  

# COMMAND ----------

# Verifica se a(s) coluna(s) foi/foram convertida(s) apresentando o index da(s) coluna(s)
columns_type = [('territoryID','int'),('regionID','int')]
df_type = territoriesCast.dtypes
confirm_column_cast(df_type,columns_type)


# COMMAND ----------

# Apresenta o novo dataframe criado com as colunas convertidas
territoriesCast


# COMMAND ----------

# MAGIC %md
# MAGIC ### Gravar os arquivos
# MAGIC 
# MAGIC Vamos gravar os novos dataframes tratados em formato parquet no diretório trusted

# COMMAND ----------

# MAGIC %md
# MAGIC #### Lista de dataframes

# COMMAND ----------

lista_dataframes = [(categoriesCast,"categories","False", ""), 
                    (customersCast, "customers","True","country"), 
                    (employee_territoriesCast, "employee_territories","True","employeeID"), 
                    (employeesCast, "employees","True","country"), 
                    (order_detailsCast, "order_details","True","productID"), 
                    (ordersCast, "orders","True","orderDate"),
                    (productsCast, "products","True","supplierID"), 
                    (regionsCast, "regions","False",""), 
                    (shippersCast, "shippers","False",""), 
                    (suppliersCast, "suppliers","True","country"), 
                    (territoriesCast, "territories","False","")]

numero_elementos = len(lista_dataframes)

print(f"Quantidade de dataframes: {numero_elementos}")


# COMMAND ----------

# MAGIC %md
# MAGIC #### Gravar dataframes
# MAGIC 
# MAGIC Vamos utilizar a função `save_trusted` para salvar o dataframe na camada trusted em formato `parquet`.
# MAGIC 
# MAGIC **Observação**: A função esta com problema, pois não esta gravando o arquivo particionado (precisa de revisão), mas não é impeditivo para gravação do arquivo.<br>
# MAGIC Como o particionamento não é obrigatório este problema não foi corrigido para entrega.
# MAGIC 
# MAGIC A função recebe os argumentos:
# MAGIC - dataframe (dataframe): Definir o nome do dataframe;
# MAGIC - columns_to_cast (list): Definir a lista com as colunas que serão convertidas;
# MAGIC - dtype (str): Definir o tipo de dado da coluna

# COMMAND ----------

ct = 0
for e in lista_dataframes:
  dataframestr = e[1] + "Cast"
  print(f"Carregando dataframe [{dataframestr}]...")
  try:
    save_trusted(e[0], northwind_data_trusted + e[1] + "/", e[2], e[3])
    ct += 1
  except:
    print(f"Erro ao carregar o arquivo.")

print(f"\nQuantidade de arquivos: {ct}")    
print(f"Processo de gravação finalizado.")


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Registrar tabela no Metastore
# MAGIC 
# MAGIC Utilizamos o Spark SQL para registrar a tabela no metastore.
# MAGIC 
# MAGIC Na criação especificamos o formato como parquet e que deve ser usado o local onde os arquivos parquet foram gravados.
# MAGIC 
# MAGIC Vamos utilizar a função `spark_create_table` para criar uma tabela utilizando a biblioteca spark com comando SQL.
# MAGIC 
# MAGIC A função recebe os argumentos:
# MAGIC - tablename (str): Definir o nome da tabela;
# MAGIC - path (str): Definir o caminho físico de destino do arquivo;
# MAGIC - is_partition (boolean): Definir se o arquivo será particionado;
# MAGIC - partitionCol (str): Definir o nome da coluna da partição;

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Criar tabela 

# COMMAND ----------

ct = 0
for e in lista_dataframes:
  tablename = e[1]
  print(f"Criando tabela [{tablename}]...")
  try:
    spark_create_table(tablename, northwind_data_trusted, e[2], e[3])
    ct += 1
  except:
    print(f"Erro ao criar a tabela [{tablename}].")

print(f"\nQuantidade de tabelas criadas: {ct}")    
print(f"Processo finalizado.")


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Verificar a tabela-parquet do Data Lake

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Contar a quantidade de registros

# COMMAND ----------

ct = 0
for e in lista_dataframes:
  tablename = e[1]
  print(f"Verificando a tabela [{tablename}]...")
  try:
    spark.catalog.refreshTable(tablename)
    print(f"Quantidade de registros: {spark.read.table(tablename).count()}")
    ct += 1
  except:
    print(f"Tabela [{tablename}] não identificada.")

print(f"\nQuantidade de tabelas lidas: {ct}")    
print(f"Processo finalizado.")


# COMMAND ----------

# MAGIC %md
# MAGIC # Camada refined
# MAGIC 
# MAGIC **Objetivo:** 
# MAGIC 
# MAGIC Neste trecho criaremos um novo database com o diagrama de dados do datawarehouse (BI) baseado nas tabelas criadas na camada trusted utilizando Delta Tables.
# MAGIC 
# MAGIC Vamos utilizar a função `spark_create_table_dw` para criar um dataframe baseado em uma pesquisa SQL (Query script) com referencia nas tabelas criadas na camada trusted, em sequencia salvamos o dataframe em formato DELTA no diretorio especificado (refined) e para finalizar registramos a tabela no Metastore.
# MAGIC 
# MAGIC A função recebe os argumentos:
# MAGIC - tablename (str): Definir o nome da tabela;
# MAGIC - path (str): Definir o caminho físico de destino do arquivo;
# MAGIC - sqlcmd (str): Definir o script de pesquisa para o conjunto de dados para criação do dataframe;
# MAGIC - database (str): Definir o nome do banco de dados para persistência da tabela;

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Limpeza do diretório

# COMMAND ----------

# Limpeza do diretório refined
print(f"Caminho: {northwind_data_refined}")
try:
  dbutils.fs.rm(northwind_data_refined, recurse=True)
  
  print("Limpeza concluida com sucesso.")
except:
  print("Erro! Ocorreu algum problema na limpeza.")


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Criar Datawarehouse

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Criar Dimensões

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### dm_customers

# COMMAND ----------

# pesquisa SQL para gerar o dataframe
sqlcmd = f"""
SELECT row_number() OVER (ORDER BY customerID) customerID_sk, customerID, companyName, contactName, contactTitle, address, city, region, postalCode, country, phone, fax
FROM customers;
"""

# Criação da tabela de dimensão
spark_create_table_dw("dm_customers", northwind_data_refined, sqlcmd, "northwind_jhorita_DW")


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### dm_employees

# COMMAND ----------

# pesquisa SQL para gerar o dataframe
sqlcmd = f"""
SELECT row_number() OVER (ORDER BY e.employeeID) employeeID_sk, 
e.employeeID, e.lastName, e.firstName, concat(e.lastName, ' ', e.firstName) AS fullName, e.title, e.titleOfCourtesy, e.birthDate, e.hireDate, e.address, e.city, e.region, e.postalCode, e.country, e.homePhone, e.extension, e.photo, e.notes, e.reportsTo, e.photoPath 
FROM employees e
"""

# Criação da tabela de dimensão
spark_create_table_dw("dm_employees", northwind_data_refined, sqlcmd, "northwind_jhorita_DW")


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### dm_employees_territories_regions

# COMMAND ----------

# pesquisa SQL para gerar o dataframe
sqlcmd = f"""
SELECT row_number() OVER (ORDER BY et.territoryID) territoryID_sk, 
et.*, e.employeeID_sk, t.territoryDescription, r.regionDescription
FROM employee_territories et
INNER JOIN northwind_jhorita_DW.dm_employees e
        ON e.employeeID = et.employeeID
INNER JOIN territories t
        ON t.territoryID = et.territoryID
INNER JOIN regions r
        ON r.regionID = t.regionID;
"""

# Criação da tabela de dimensão
spark_create_table_dw("dm_employees_territories_regions", northwind_data_refined, sqlcmd, "northwind_jhorita_DW")


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### dm_shippers

# COMMAND ----------

# pesquisa SQL para gerar o dataframe
sqlcmd = f"""
SELECT row_number() OVER (ORDER BY shipperID) shipperID_sk, 
shipperID, companyName, phone
FROM shippers;
"""

# Criação da tabela de dimensão
spark_create_table_dw("dm_shippers", northwind_data_refined, sqlcmd, "northwind_jhorita_DW")


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### dm_products

# COMMAND ----------

# pesquisa SQL para gerar o dataframe
sqlcmd = f"""
SELECT row_number() OVER (ORDER BY p.productID) productID_sk, 
p.productID, p.productName, p.quantityPerUnit, p.unitPrice, p.unitsInStock, p.unitsOnOrder, p.reorderLevel, p.discontinued
,p.supplierID, s.companyName, s.contactName, s.contactTitle, s.address, s.city, s.region, s.postalCode, s.country, s.phone, s.fax, s.homePage
,p.categoryID, c.categoryName, c.description, c.picture
FROM products p
INNER JOIN suppliers s
        ON s.supplierID = p.supplierID
INNER JOIN categories c
        ON c.categoryID = p.categoryID;
"""

# Criação da tabela de dimensão
spark_create_table_dw("dm_products", northwind_data_refined, sqlcmd, "northwind_jhorita_DW")


# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### Criar Fato

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ##### ft_orders

# COMMAND ----------

# pesquisa SQL para gerar o dataframe
sqlcmd = f"""
SELECT row_number() OVER (ORDER BY o.orderID) orderID_sk,
o.orderID, c.customerID_sk, e.employeeID_sk, o.orderDate, o.requiredDate, o.shippedDate, s.shipperID_sk, o.freight, o.shipName, o.shipAddress, o.shipCity, o.shipRegion, o.shipPostalCode, o.shipCountry
,p.productID_sk, od.unitPrice, od.quantity, od.discount
,cast(((od.unitPrice*od.quantity*(1-od.discount)/100)*100) AS DECIMAL(18,2)) AS subTotal
FROM orders o
INNER JOIN order_details od
        ON od.orderID = o.orderID
INNER JOIN northwind_jhorita_DW.dm_customers c
        ON c.customerID = o.customerID
INNER JOIN northwind_jhorita_DW.dm_employees e
        ON e.employeeID = o.employeeID
INNER JOIN northwind_jhorita_DW.dm_shippers s
        ON s.shipperID = o.shipVia
INNER JOIN northwind_jhorita_DW.dm_products p
        ON p.productID = od.productID;
"""

# Criação da tabela fato
spark_create_table_dw("ft_orders", northwind_data_refined, sqlcmd, "northwind_jhorita_DW")


# COMMAND ----------



# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Alterando as colunas surrogate key para não receber valores nulos para "garantir" a integridade da fato
# MAGIC 
# MAGIC -- Observação:
# MAGIC -- As colunas _sk (surrogates keys) não foram criadas com auto-incremento devem ser tratadas futuramente no processo de novas ingestões de dados;
# MAGIC 
# MAGIC -- dm_customers
# MAGIC ALTER TABLE northwind_jhorita_DW.dm_customers ALTER customerID_sk SET NOT NULL;
# MAGIC -- dm_employees
# MAGIC ALTER TABLE northwind_jhorita_DW.dm_employees ALTER employeeID_sk SET NOT NULL;
# MAGIC -- dm_employees_territories_regions
# MAGIC ALTER TABLE northwind_jhorita_DW.dm_employees_territories_regions ALTER territoryID_sk SET NOT NULL;
# MAGIC -- dm_shippers
# MAGIC ALTER TABLE northwind_jhorita_DW.dm_shippers ALTER shipperID_sk SET NOT NULL;
# MAGIC -- dm_products
# MAGIC ALTER TABLE northwind_jhorita_DW.dm_products ALTER productID_sk SET NOT NULL;
# MAGIC -- ft_orders
# MAGIC ALTER TABLE northwind_jhorita_DW.ft_orders ALTER orderID_sk SET NOT NULL;

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Tabelas de agregação
# MAGIC 
# MAGIC Neste trecho iremos realizar as seguintes atividades:
# MAGIC 
# MAGIC * Apagar o arquivo relacionado; 
# MAGIC * Criar o dataframe com agregação;
# MAGIC * Gravar o dataframe no formato `DELTA`;
# MAGIC * Registrar a tabela Delta no Metastore;

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### order_details_refined_user_analytics
# MAGIC 
# MAGIC Detalhe dos Pedidos: Criaremos uma tabela agregada a partir da tabela `order_details_trusted` com o valor total do pedido, ou seja, a somatória dos valores dos itens do pedido com o seu respectivo desconto.

# COMMAND ----------

# Apagar o arquivo relacionado
dbutils.fs.rm(northwind_data_refined + "order_details_refined_user_analytics", recurse=True)

# Criar o dataframe com métrica de agregação 
order_details_refined_user_analytics = (
  spark.read.table("order_details")
  .groupby("orderID")
  .agg( sum((col("unitPrice")*col("quantity")*(1-col("discount")/100))*100 ).alias("Total")
  )
)

# Gravar o dataframe no formato Delta
(order_details_refined_user_analytics.write
 .format("delta")
 .mode("overwrite")
 .save(northwind_data_refined + "order_details_refined_user_analytics"))

# Registrar a tabela Delta no Metastore
spark.sql(f"""
DROP TABLE IF EXISTS order_details_refined_user_analytics
""")

spark.sql(f"""
CREATE TABLE order_details_refined_user_analytics
USING DELTA
LOCATION "{northwind_data_refined}order_details_refined_user_analytics"
""")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC #### products_refined_user_analytics
# MAGIC 
# MAGIC Products: Criaremos uma tabela agregada a partir da tabela `products_trusted` com a quantidade total de produtos agrupados por fornecedor.

# COMMAND ----------

# Apagar o arquivo relacionado
dbutils.fs.rm(northwind_data_refined + "products_refined_user_analytics", recurse=True)

# Criar o dataframe com métrica de agregação 
products_refined_user_analytics = (
  spark.read.table("products")
  .groupby("supplierID")
  .agg( count(col("supplierID") ).alias("qtdProduct")
  )
)

# Gravar o dataframe no formato Delta
(products_refined_user_analytics.write
 .format("delta")
 .mode("overwrite")
 .save(northwind_data_refined + "products_refined_user_analytics"))

# Registrar a tabela Delta no Metastore
spark.sql(f"""
DROP TABLE IF EXISTS products_refined_user_analytics
""")

spark.sql(f"""
CREATE TABLE products_refined_user_analytics
USING DELTA
LOCATION "{northwind_data_refined}products_refined_user_analytics"
""")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Adicionar/Alterar comentários
# MAGIC 
# MAGIC Neste trecho vamos adicionar/alterar os comentários das colunas das tabelas

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Tabela order_details_refined_user_analytics
# MAGIC 
# MAGIC ALTER TABLE
# MAGIC   order_details_refined_user_analytics
# MAGIC REPLACE COLUMNS
# MAGIC   (orderid INT COMMENT "Código único de identificação do pedido", 
# MAGIC   Total DOUBLE COMMENT "Valor total do pedido"
# MAGIC   );

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- Tabela products_refined_user_analytics
# MAGIC 
# MAGIC ALTER TABLE
# MAGIC   products_refined_user_analytics
# MAGIC REPLACE COLUMNS
# MAGIC   (supplierID INT COMMENT "Código único de identificação do fornecedor", 
# MAGIC   qtdProduct BIGINT COMMENT "Quantidade de produtos oferecidos pelo fornecedor"
# MAGIC   );

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Visualizar comentários

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC DESCRIBE EXTENDED order_details_refined_user_analytics;

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC DESCRIBE EXTENDED products_refined_user_analytics;

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### Visualizar dados tabelas Agregadas

# COMMAND ----------

# Selecionar os dados da tabela order_details_refined_user_analytics utilizando Python

display(order_details_refined_user_analytics)


# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select * from products_refined_user_analytics

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC -- selecionar os dados da tabela products_refined_user_analytics utilizando SQL
# MAGIC 
# MAGIC select p.supplierID, s.companyName, p.qtdProduct 
# MAGIC from products_refined_user_analytics p
# MAGIC inner join suppliers s 
# MAGIC         on s.supplierID = p.supplierID
# MAGIC order by p.qtdProduct desc

# COMMAND ----------

# MAGIC %md
# MAGIC # Análises com Apache Spark
# MAGIC 
# MAGIC **Objetivo:** 
# MAGIC 
# MAGIC Utilizaremos este trecho para efetuar algumas consultas no datawarehouse, é obrigatória a execução da célula abaixo para direcionar o banco de dados.

# COMMAND ----------

# Definir a utilização do banco de dados do Datawarehouse
spark.sql(f"USE {project}_{username}_dw")

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### 1 - Quais são os três produtos MENOS vendidos?

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select p.productName, count(o.productID_sk) AS qtdProducts 
# MAGIC from       ft_orders o
# MAGIC inner join dm_products p
# MAGIC         on p.productID_sk = o.productID_sk
# MAGIC group by p.productName
# MAGIC order by 2 asc
# MAGIC limit 3

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### 2 - Quais são os cinco clientes que mais compras fizeram?

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC WITH Orders_CTE (orderID, companyName)  
# MAGIC AS  
# MAGIC (  
# MAGIC 	SELECT	o.orderID, c.companyName
# MAGIC 	FROM		ft_orders o
# MAGIC 	INNER JOIN	dm_customers c
# MAGIC 			ON	c.customerID_sk = o.customerID_sk
# MAGIC 	GROUP BY o.orderID, o.customerID_sk, c.companyName
# MAGIC )  
# MAGIC -- Define the outer query referencing the CTE name.  
# MAGIC SELECT companyName, COUNT(companyName) AS qtdOrders
# MAGIC FROM Orders_CTE 
# MAGIC GROUP BY companyName
# MAGIC ORDER BY qtdOrders DESC
# MAGIC limit 5;

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### 3 - Quais são os cinco clientes com maior total de vendas?

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC WITH Orders_CTE (orderID, companyName, subTotal)  
# MAGIC AS  
# MAGIC (  
# MAGIC     SELECT	o.orderID, c.companyName, sum(subTotal) AS subTotal
# MAGIC 	FROM		ft_orders o
# MAGIC 	INNER JOIN	dm_customers c
# MAGIC 			ON	c.customerID_sk = o.customerID_sk
# MAGIC 	GROUP BY o.orderID, o.customerID_sk, c.companyName
# MAGIC )  
# MAGIC -- Define the outer query referencing the CTE name.  
# MAGIC SELECT companyName, sum(subTotal) AS Total
# MAGIC FROM Orders_CTE 
# MAGIC GROUP BY companyName
# MAGIC ORDER BY Total DESC
# MAGIC limit 5;

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### 4 - Qual o melhor funcionário do último mês registrado? (total de vendas)

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC SELECT MAX(orderDate) from ft_orders;

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC WITH Orders_CTE (orderID, fullName, subTotal, orderDate, dtYear, dtMonth)  
# MAGIC AS  
# MAGIC (  
# MAGIC     SELECT	o.orderID, e.fullName, sum(subTotal) AS subTotal 
# MAGIC     ,date_format(o.orderDate, "yMM") AS dtYM
# MAGIC     ,date_format(o.orderDate, "y") AS dtYear
# MAGIC     ,date_format(o.orderDate, "MM") AS dtMonth
# MAGIC 	FROM		ft_orders o
# MAGIC 	INNER JOIN	dm_employees e
# MAGIC 			ON	e.employeeID_sk = o.employeeID_sk
# MAGIC     WHERE o.orderDate = (SELECT MAX(orderDate) from ft_orders)
# MAGIC 	GROUP BY o.orderID, e.employeeID_sk, e.fullName, dtYM, dtYear, dtMonth
# MAGIC )  
# MAGIC -- Define the outer query referencing the CTE name.  
# MAGIC SELECT fullName, sum(subTotal) AS subTotal
# MAGIC FROM Orders_CTE
# MAGIC GROUP BY fullName
# MAGIC ORDER BY subTotal DESC

# COMMAND ----------

# MAGIC %md
# MAGIC 
# MAGIC ### 5 - Quais as regiões com menos clientes cadastrados?

# COMMAND ----------

# MAGIC %sql
# MAGIC 
# MAGIC select region, count(region) AS qtdCustomers 
# MAGIC from dm_customers
# MAGIC group by region 
# MAGIC order by qtdCustomers; 

# COMMAND ----------

# retornar a definição do banco de dados principal
spark.sql(f"USE {project}_{username}")

# COMMAND ----------

